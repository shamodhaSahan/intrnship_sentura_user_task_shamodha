import "./App.css";
import Userpage from "./pages/user.pages";

function App() {
  return (
    <div>
      <Userpage />
    </div>
  );
}

export default App;
